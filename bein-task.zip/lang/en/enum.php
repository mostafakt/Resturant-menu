<?php

return [
    'order' => [
        'status' => [
            '1' => 'searching for pharmacy',
            '2' => 'preparing',
            '3' => 'completing order',
            '4' => 'wait customer for accept',
            '5' => 'searching for delivery driver',
            '6' => 'en route to customer prescription received',
            '7' => 'en route to customer product pickup',
            '8' => 'completed and paid',
            '9' => 'cancelled by pharmacist',
            '10' => 'cancelled by customer',
            '11' => 'cancelled by administration',
            '12' => 'emergency by driver',
        ]
    ],
];
