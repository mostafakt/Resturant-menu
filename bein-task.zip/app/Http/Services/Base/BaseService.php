<?php

namespace App\Http\Services\Base;

abstract class BaseService
{

}
