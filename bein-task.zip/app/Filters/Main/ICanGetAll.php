<?php

namespace App\Filters\Main;

interface ICanGetAll
{

}
